export { default } from './TotalMovies';
