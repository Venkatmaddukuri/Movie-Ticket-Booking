export { default } from './CinemaToolbar';
