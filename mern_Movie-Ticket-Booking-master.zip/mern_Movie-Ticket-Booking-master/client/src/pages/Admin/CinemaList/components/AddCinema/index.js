export { default } from './AddCinema';
