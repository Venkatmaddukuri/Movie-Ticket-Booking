export { default } from './CinemaList';
