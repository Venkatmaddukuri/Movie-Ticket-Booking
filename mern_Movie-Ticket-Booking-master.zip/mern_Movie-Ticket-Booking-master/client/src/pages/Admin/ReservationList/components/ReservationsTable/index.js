export { default } from './ReservationTable';
