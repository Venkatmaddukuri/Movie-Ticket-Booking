export { default } from './MoviePage';
