export default theme => ({
  grid: {
    height: '100%'
  },
  carousel: { marginBottom: theme.spacing(6) }
});
