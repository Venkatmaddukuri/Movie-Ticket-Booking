export { default } from './MovieCategoryPage';
