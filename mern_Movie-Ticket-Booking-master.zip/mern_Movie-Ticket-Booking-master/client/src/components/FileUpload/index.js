export { default } from './FileUpload';
