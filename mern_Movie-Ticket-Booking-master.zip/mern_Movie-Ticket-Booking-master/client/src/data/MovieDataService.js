export const genreData = [
  'action',
  'adventure',
  'comedy',
  'drama',
  'fantasy',
  'historical',
  'horror',
  'mystery',
  'romance',
  'science fiction',
  'thriller',
  'political',
  'western'
];

export const languageData = ['english', 'greek', 'german', 'french'];
